﻿Public Class Form1
    Const dblTaxRate As Single = 0.07
    Const dblCutRate As Single = 0.2
    Dim intTotalTickets As Integer
    Dim dblGrossSales As Double
    Dim dblProfit As Double
    Dim dblPromoterCut As Double


    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Declare Variables
        Dim intTicketSold As Integer
        Dim intIndividualPrice As Integer
        Dim dblTotalPrice As Double
        Dim dblTotalPriceTax As Double

        'Get Inputs
        intTicketSold = txtTicketSold.Text
        intIndividualPrice = txtIndividualPrice.Text

        'Do Calculation

        'Customer purchase
        dblTotalPrice = intTicketSold * intIndividualPrice
        dblTotalPriceTax = dblTotalPrice * (1 + dblTaxRate)

        'Daily Summary
        intTotalTickets += intTicketSold
        dblGrossSales += dblTotalPrice
        dblPromoterCut = dblGrossSales * dblCutRate
        dblProfit = dblGrossSales - dblPromoterCut

        'Output
        lblTotalPrice.Text = FormatCurrency(dblTotalPrice)
        lblTaxRate.Text = dblTaxRate
        lblTotalPriceTax.Text = FormatCurrency(dblTotalPriceTax)
        lblTotalTickets.Text = intTotalTickets
        lblGrossSales.Text = FormatCurrency(dblGrossSales)
        lblPromoterCut.Text = FormatCurrency(dblPromoterCut)
        lblProfit.Text = FormatCurrency(dblProfit)




    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtTicketSold.Clear()
        txtIndividualPrice.Clear()
        lblTotalPrice.ResetText()
        lblTotalPriceTax.ResetText()
        lblTaxRate.ResetText()
        txtTicketSold.Focus()

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class
